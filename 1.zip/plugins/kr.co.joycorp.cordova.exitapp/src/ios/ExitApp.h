#import <Cordova/CDV.h>

@interface ExitApp : CDVPlugin

- (void)exitApp:(CDVInvokedUrlCommand *)command;

@end