## Force App Close
======
* this is a simple plugin to force app close programatically 
###Install 
  `cordova plugin add mo-force-app-close`
### Usage
``` MOForceAppClose.forceAppClose() ```
### Repo 
https://github.com/EngMoathOmar/MOForceAppClose

