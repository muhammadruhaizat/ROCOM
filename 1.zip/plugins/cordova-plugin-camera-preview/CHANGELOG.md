# Changelog

# 0.11.0 - UNRELEASED
  - Add Changelog
  - [PR #441](https://github.com/cordova-plugin-camera-preview/cordova-plugin-camera-preview/pull/441) - Add option `storeToFile` for storage in temporary file instead of base64
  - [PR #396](https://github.com/cordova-plugin-camera-preview/cordova-plugin-camera-preview/pull/396) - Add function `getCameraCharacteristics`

# 0.10.0 - LATEST RELEASED

# 0.9.0

# 0.0.8

# 0.0.6

# 0.0.3

# 0.0.2
