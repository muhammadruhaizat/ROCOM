export default {
  name: 'chip',
};
