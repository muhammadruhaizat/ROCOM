export default {
  name: 'contactList',
};
