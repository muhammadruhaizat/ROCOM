export default {
  name: 'typography',
};
