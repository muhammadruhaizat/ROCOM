export default {
  name: 'card',
};
