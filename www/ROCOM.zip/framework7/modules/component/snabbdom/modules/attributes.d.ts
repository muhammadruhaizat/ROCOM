import { Module } from './module';
export declare type Attrs = Record<string, string | number | boolean>;
export declare const attributesModule: Module;
export default attributesModule;
