import setTransition from './setTransition';
import transitionStart from './transitionStart';
import transitionEnd from './transitionEnd';

export default {
  setTransition,
  transitionStart,
  transitionEnd,
};
