export default {
  name: 'timeline',
};
