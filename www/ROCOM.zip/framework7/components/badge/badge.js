export default {
  name: 'badge',
};
