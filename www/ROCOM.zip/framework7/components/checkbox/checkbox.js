export default {
  name: 'checkbox',
};
