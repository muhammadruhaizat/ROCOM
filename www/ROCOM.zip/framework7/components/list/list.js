export default {
  name: 'list',
};
