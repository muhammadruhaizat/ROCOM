export default {
  name: 'link',
};
